
package natural.number;
import java.util.Scanner;
public class NaturalNumber {
static void CheckNumber(int a)
{
    int count=0;
    String all="";boolean test=false;
for(int i=2;i<=a/2;i++){
    count++;
if(a%i==0){
    test=true;
   all=all+i+", ";}
}
if(test==true){
System.out.println(a+"   is composite number and factors are  "+ "( "+all + a+" )");
System.out.println("With 1st method number of iteration  is  "+count);}
else 
{
System.out.println(a+"   is prime number and factors are  "+"( "+a+" )");
System.out.println("With 1st method number of iteration  is  "+count);
}
}

    public static void main(String[] args) { 
 System.out.println("Please Input Nutural Number");
 Scanner in = new Scanner(System.in);
 int number = in.nextInt();
if(number<=1){
    System.out.println("the number must be greater than 1 to check if its Composite or Prime");
}
else
CheckNumber(number);

                 
                 
    }
    
}
