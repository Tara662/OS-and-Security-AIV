
package natural.number;
import java.util.Scanner;
public class NaturalNumber {
static void FirstMethod(int a)
{
    int count=0;
    String all="";boolean test=false;
for(int i=2;i<=a/2;i++){
    count++;
if(a%i==0){
    test=true;
   all=all+i+", ";}
}
if(test==true){
System.out.println(a+"   is composite number and factors are  "+ "( "+all + a+" )");
System.out.println("With 1st method number of iteration  is  "+count);}
else 
{
System.out.println(a+"   is prime number and factors are  "+"( "+a+" )");
System.out.println("With 1st method number of iteration  is  "+count);
}
}
static void SecoundMethod(int a)
{
    int count=0;
    boolean test=false;
    int i=2;
    int x=(int)Math.sqrt(a);
while(i<=x){
    count++;
if(a%i==0){
    test=true;
}
i++;
}
if(test==true){
System.out.println("With 2nd method number of iteration  is  "+count);}

else 
{
System.out.println("With 2nd method number of iteration  is  "+count);
}
}
    public static void main(String[] args) { 
 System.out.println("Please give a  number");
 Scanner in = new Scanner(System.in);
 int number = in.nextInt();
if(number<=1){
    System.out.println("The number must be greater than 1 to check if its Prime or Composite");
}
else
{
FirstMethod(number);
SecoundMethod(number);
}              
                 
    }
    
}
